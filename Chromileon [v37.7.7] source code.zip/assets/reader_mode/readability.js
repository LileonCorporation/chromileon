
var readability = {
    version:     '0.1',
    emailSrc:    '',
    kindleSrc:   '',
    iframeLoads: 0,
    frameHack:   false, /**
                         * The frame hack is to workaround a firefox bug where if you
                         * pull content out of a frame and stick it into the parent element, the scrollbar won't appear.
                         * So we fake a scrollbar in the wrapping div.
                        **/
    bodyCache:  null,   /* Cache the body HTML in case we need to re-use it later */
    webviewId:  0,
    extractedContent: "",

    /**
     * All of the regular expressions in use within readability.
     * Defined up here so we don't instantiate them repeatedly in loops.
     **/
    regexps: {
        unlikelyCandidatesRe:   /combx|comment|disqus|foot|menu|meta|nav|rss|shoutbox|sidebar|sponsor|video|overlay/i,
        okMaybeItsACandidateRe: /and|article|body|column|main|header/i,
        positiveRe:             /article|body|content|entry|hentry|page|pagination|post|text|h1|h2|header|title/i,
        negativeRe:             /combx|comment|contact|foot|footer|footnote|link|media|meta|promo|related|scroll|shoutbox|sponsor|tags|widget|ads/i,
        divToPElementsRe:       /<(a|blockquote|dl|div|img|ol|p|pre|table|ul|select|video)/i,
        replaceBrsRe:           /(<br[^>]*>[ \n\r\t]*){2,}/gi,
        replaceFontsRe:         /<(\/?)font[^>]*>/gi,
        trimRe:                 /^\s+|\s+$/g,
        normalizeRe:            /\s{2,}/g,
        killBreaksRe:           /(<br\s*\/?>(\s|&nbsp;?)*){1,}/g
    },

    dbg : function(s) {
        if(typeof console !== 'undefined')
            console.log("Readability: " + s);
    },

    /* called by webview
    */
    initialize: function(id) {
        try {
            if (typeof id != 'undefined') {
                readability.webviewId = id;
                console.log("readability.webviewId:" + readability.webviewId);
            }
            readability.init();
        } catch (e) {
            console.log(e);
        }
    },

    /**
     * Runs readability.
     * 
     * Workflow:
     *  1. Prep the document by removing script tags, css, etc.
     *  2. Build readability's DOM tree.
     *  3. Grab the article content from the current dom tree.
     *  4. Replace the current DOM tree with the new one.
     *  5. Read peacefully.
     *
     * @return void
     **/
    init: function(preserveUnlikelyCandidates) {
        console.log(Date.now() + " start readability init");
        if (typeof(window.readermode) == "undefined") {
            console.log("can't find readermode");
            return;
        } 

        preserveUnlikelyCandidates = (typeof preserveUnlikelyCandidates == 'undefined') ? false : preserveUnlikelyCandidates;

        var startTime = Date.now();

        if(document.body && !readability.bodyCache)
            readability.bodyCache = document.body.innerHTML;
        
        var cleanBody = readability.prepDocument();

        var articleContent = readability.grabArticle(cleanBody, false);

        var endTime = Date.now();

        console.log("benchmark " + (endTime - startTime));
        if(articleContent) {
            var panel = readability.createFeedbackPanel();
            articleContent.appendChild(panel);
            readability.extractedContent = articleContent.innerHTML;
            console.log("content is extracted successful");
        } else {
            console.log("there is no main content");
        } 

        readability.updateReaderModeAccessible();
        console.log(Date.now() + " readability finished");
    },

    grabStyleSheets: function() {
        var styleSheets = [];
        if (document.body.styleSheets) {
            for (var k=0;k < document.body.styleSheets.length; k++) {
                var url = document.body.styleSheets[k].href;
                if (url != null) {
                    styleSheets.push(url);
                }
            }
        }
        var styleTags = document.body.getElementsByTagName("style");
        if (styleTags) {
            for (var j=0;j < styleTags.length; j++)
                styleSheets.push(styleTags[j].textContent);
        }
        console.log("stylesheets count : " + styleSheets.length);
        return styleSheets;
    },

    /**
     * find the nearest H1/H2 in the html,
     * otherwise, use the document title
     * @return void
     **/
    grabArticleTitle: function (article, topCandidateStart, topCandidateLength) {
        console.log("top candidate pos:" + topCandidateStart + "," + topCandidateLength);
        var nearestPos = 0;
        var bestTitle = null;
        var bestH1Pos = 0;
        for (var headerIndex = 1; headerIndex < 3; headerIndex++) {
            var headers = article.getElementsByTagName('H' + headerIndex);
            if (headers != null && headers.length > 0) {
                for (var i=0; i<headers.length; i++) {
                    var header = headers[i];
                    var titlePos = article.innerHTML.indexOf(header.innerHTML);
                    console.log("title candidate: " + titlePos + ": " + header.innerHTML);
                    if(titlePos < topCandidateStart + topCandidateLength) {
                        if (titlePos > nearestPos) {
                            if (headerIndex ==1 ) {
                                bestH1Pos = titlePos;
                            }
                            if (titlePos - bestH1Pos < 500) {
                                nearestPos = titlePos;
                                bestTitle = header;
                            }
                            
                        }
                    }
                }
            }
        }

        if (bestTitle != null) {
            console.log("best title:" + bestTitle.innerHTML);
        } else if(document.title != null) {
            bestTitle = document.createElement('h1');
            bestTitle.innerHTML = document.title;
            article.insertBefore(bestTitle, article.firstChild);
            console.log("create new title:" + bestTitle.innerHTML);
        }
    },

    /**
     * Prepare the HTML document for readability to scrape it.
     * This includes things like stripping javascript, CSS, and handling terrible markup.
     * 
     * @return void
     **/
    prepDocument: function () {
        /**
         * In some cases a body element can't be found (if the HTML is totally hosed for example)
         * so we create a new body node and append it to the document.
         */
        if(document.body === null)
        {
            body = document.createElement("body");
            try {
                document.body = body;        
            }
            catch(e) {
                document.documentElement.appendChild(body);
            }
        }

        var frames = document.getElementsByTagName('frame');
        if(frames.length > 0)
        {
            var bestFrame = null;
            var bestFrameSize = 0;
            for(var frameIndex = 0; frameIndex < frames.length; frameIndex++)
            {
                var frameSize = frames[frameIndex].offsetWidth + frames[frameIndex].offsetHeight;
                var canAccessFrame = false;
                try {
                    frames[frameIndex].contentWindow.document.body;
                    canAccessFrame = true;
                } catch(e) {}
                
                if(canAccessFrame && frameSize > bestFrameSize)
                {
                    bestFrame = frames[frameIndex];
                    bestFrameSize = frameSize;
                }
            }

            if(bestFrame)
            {
                var newBody = document.createElement('body');
                newBody.innerHTML = bestFrame.contentWindow.document.body.innerHTML;
                newBody.style.overflow = 'scroll';
                document.body = newBody;
                
                var frameset = document.getElementsByTagName('frameset')[0];
                if(frameset)
                    frameset.parentNode.removeChild(frameset);
                    
                readability.frameHack = true;
            }
        }

        var cloneBody = document.body.cloneNode(true);

        /* remove all scripts that are not readability */
        var scripts = cloneBody.getElementsByTagName('script');
        for(i = scripts.length-1; i >= 0; i--)
        {
            if(typeof(scripts[i].src) == "undefined" || scripts[i].src.indexOf('readability') == -1)
            {
                scripts[i].parentNode.removeChild(scripts[i]);            
            }
        }
        /* remove all <noscript> that are not readability */
        var noscripts = cloneBody.getElementsByTagName('noscript');
        for(i = noscripts.length-1; i >= 0; i--)
        {
            if(typeof(noscripts[i].src) == "undefined" || noscripts[i].src.indexOf('readability') == -1)
            {
                noscripts[i].parentNode.removeChild(noscripts[i]);            
            }
        }

        /* remove all stylesheets */
        /*
        for (var k=0;k < cloneBody.styleSheets.length; k++) {
            if (cloneBody.styleSheets[k].href != null && cloneBody.styleSheets[k].href.lastIndexOf("readability") == -1) {
                cloneBody.styleSheets[k].disabled = true;
            }
        }
        */

        /* Remove all style tags in head (not doing this on IE) - TODO: Why not? */
        var styleTags = cloneBody.getElementsByTagName("style");
        for (var j=0;j < styleTags.length; j++)
            styleTags[j].textContent = "";

        return cloneBody;
        /* Turn all double br's into p's */
        /* Note, this is pretty costly as far as processing goes. Maybe optimize later. */
        //document.body.innerHTML = document.body.innerHTML.replace(readability.regexps.replaceBrsRe, '</p><p>').replace(readability.regexps.replaceFontsRe, '<$1span>')
    },

    /**
     * Prepare the article node for display. Clean out any inline styles,
     * iframes, forms, strip extraneous <p> tags, etc.
     *
     * @param Element
     * @return void
     **/
    prepArticle: function (articleContent) {


        readability.cleanStyles(articleContent);
        //readability.killBreaks(articleContent);

        //readability.logMarkState(articleContent);

        /* Clean out junk from the article content */
        readability.clean(articleContent, "form");
        readability.clean(articleContent, "object");
        //readability.clean(articleContent, "h1");
        /**
         * If there is only one h2, they are probably using it
         * as a header and not a subheader, so remove it since we already have a header.
        ***/
        //if(articleContent.getElementsByTagName('h2').length == 1)
        //    readability.clean(articleContent, "h2");
        readability.clean(articleContent, "iframe");

        //readability.cleanHeaders(articleContent);

        /* Do these last as the previous stuff may have removed junk that will affect these */
        readability.cleanConditionally(articleContent, "table");
        readability.cleanConditionally(articleContent, "ul");

        readability.cleanConditionally(articleContent, "div");
        console.log("header removed: " + articleContent.getElementsByTagName('H2').length);

        /* Remove extra paragraphs */
        var articleParagraphs = articleContent.getElementsByTagName('p');
        for(i = articleParagraphs.length-1; i >= 0; i--)
        {
            var imgCount    = articleParagraphs[i].getElementsByTagName('img').length;
            var embedCount  = articleParagraphs[i].getElementsByTagName('embed').length;
            var objectCount = articleParagraphs[i].getElementsByTagName('object').length;
            var headerCount = articleParagraphs[i].getElementsByTagName('h1').length;

            if(imgCount == 0 && embedCount == 0 && objectCount == 0 && readability.getInnerText(articleParagraphs[i], false) == '' && headerCount != 1)
            {
                articleParagraphs[i].parentNode.removeChild(articleParagraphs[i]);
            }
        }
/*
        try {
            articleContent.innerHTML = articleContent.innerHTML.replace(/<br[^>]*>\s*<p/gi, '<p');        
        }
        catch (e) {
            console.log("Cleaning innerHTML of breaks failed. This is an IE strict-block-elements bug. Ignoring.");
        }
*/
    },
    
    /**
     * Initialize a node with the readability object. Also checks the
     * className/id for special names to add to its score.
     *
     * @param Element
     * @return void
    **/
    initializeNode: function (node) {
        node.readability = {"contentScore": 0};            

        switch(node.tagName) {
            case 'DIV':
                node.readability.contentScore += 5;
                break;

            case 'P':
                node.readability.contentScore += 10;
                break;

            case 'PRE':
            case 'TD':
            case 'BLOCKQUOTE':
                node.readability.contentScore += 3;
                break;
                
            case 'ADDRESS':
            case 'OL':
            case 'UL':
            case 'DL':
            case 'DD':
            case 'DT':
            case 'LI':
            case 'FORM':
                node.readability.contentScore -= 10;
                break;

            case 'H1':
            case 'H2':
            case 'H3':
            case 'H4':
            case 'H5':
            case 'H6':
                 node.readability.contentScore += 5;
                 break;

            case 'TH':
                node.readability.contentScore -= 5;
                break;
        }

        node.readability.contentScore += readability.getClassWeight(node);
    },
    
    /***
     * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
     *               most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
     *
     * @return Element
    **/
    grabArticle: function (cleanBody, preserveUnlikelyCandidates) {
        /**
         * First, node prepping. Trash nodes that look cruddy (like ones with the class name "comment", etc), and turn divs
         * into P tags where they have been used inappropriately (as in, where they contain no other block level elements.)
         *
         * Note: Assignment from index for performance. See http://www.peachpit.com/articles/article.aspx?p=31567&seqNum=5
         * TODO: Shouldn't this be a reverse traversal?
        **/

        var totalLength = readability.getInnerText(cleanBody, true).length;

        for(var nodeIndex = 0; (node = cleanBody.getElementsByTagName('*')[nodeIndex]); nodeIndex++)
        {
            /* Remove unlikely candidates */
            if (!preserveUnlikelyCandidates) {
                var unlikelyMatchString = node.className + node.id;
                if (unlikelyMatchString.search(readability.regexps.unlikelyCandidatesRe) !== -1 &&
                    unlikelyMatchString.search(readability.regexps.okMaybeItsACandidateRe) == -1 &&
                    node.tagName !== "BODY")
                {
                    console.log("Removing unlikely candidate - " + unlikelyMatchString);
                    node.parentNode.removeChild(node);
                    nodeIndex--;
                    continue;
                }         
            }

            /* Turn all divs that don't have children block level elements into p's */
            if (node.tagName === "DIV") {
                if (typeof node.style != 'undefined' && node.style.display === 'none') {
                    continue;
                }
                if (node.innerHTML.search(readability.regexps.divToPElementsRe) === -1)    {
                    console.log("Altering div to p");
                    var newNode = document.createElement('p');
                    try {
                        newNode.innerHTML = node.innerHTML;                
                        node.parentNode.replaceChild(newNode, node);
                        nodeIndex--;
                    }
                    catch(e)
                    {
                        console.log("Could not alter div to p, probably an IE restriction, reverting back to div.")
                    }
                }
            } 
        }

        /**
         * Loop through all paragraphs, and assign a score to them based on how content-y they look.
         * Then add their score to their parent node.
         *
         * A score is determined by things like number of commas, class names, etc. Maybe eventually link density.
        **/
        var allParagraphs = cleanBody.getElementsByTagName("p");
        var candidates    = [];

        for (var j=0; j    < allParagraphs.length; j++) {
            if(allParagraphs[j].style.display == "none")
                continue;
            
            var parentNode      = allParagraphs[j].parentNode;
            var grandParentNode = parentNode == null ? null : parentNode.parentNode;
            var innerText       = readability.getInnerText(allParagraphs[j], false);
            var linkDensity     = readability.getLinkDensity(allParagraphs[j]);
            /* If this paragraph is less than 25 characters, don't even count it. */
            if(innerText.length < 25)
                continue;
            if(linkDensity > 0.5)
                continue;
            /* Initialize readability data for the parent. */
            if(parentNode != null && typeof parentNode.readability == 'undefined')
            {
                readability.initializeNode(parentNode);
                candidates.push(parentNode);
            }

            /* Initialize readability data for the grandparent. */
            if(grandParentNode != null && typeof grandParentNode.readability == 'undefined')
            {
                readability.initializeNode(grandParentNode);
                candidates.push(grandParentNode);
            }

            var contentScore = 0;

            /* Add a point for the paragraph itself as a base. */
            contentScore++;

            /* Add points for any commas within this paragraph */
            contentScore += innerText.split(',').length;
            contentScore += innerText.split('，').length;
            
            /* For every 100 characters in this paragraph, add another point. Up to 3 points. */
            contentScore += Math.min(Math.floor(innerText.length / 100), 3);
            
            /* Add the score to the parent. The grandparent gets half. */
            if (parentNode != null)
                parentNode.readability.contentScore += contentScore;
            if (grandParentNode != null)
                grandParentNode.readability.contentScore += contentScore/2;
        }

        /**
         * After we've calculated scores, loop through all of the possible candidate nodes we found
         * and find the one with the highest score.
        **/
        var topCandidate = null;
        for(var i=0, il=candidates.length; i < il; i++)
        {
            /**
             * Scale the final candidates score based on link density. Good content should have a
             * relatively small link density (5% or less) and be mostly unaffected by this operation.
            **/
            candidates[i].readability.contentScore = candidates[i].readability.contentScore * (1-readability.getLinkDensity(candidates[i]));

            console.log('Candidate: ' + candidates[i] + " (" + candidates[i].className + ":" + candidates[i].id + ") with score " + candidates[i].readability.contentScore);

            if(!topCandidate || candidates[i].readability.contentScore > topCandidate.readability.contentScore)
                topCandidate = candidates[i];
        }

        /**
         * If we still have no top candidate, just use the body as a last resort.
         * We also have to copy the body node so it is something we can modify.
         **/
        if (topCandidate == null || topCandidate.tagName == "BODY" || topCandidate.readability.contentScore < 12 || readability.hasInvalidParent(topCandidate))
        {
            return null;
        } else {
            console.log("top candidate found:" + topCandidate.tagName + "|" + topCandidate.className + ") with score " + topCandidate.readability.contentScore);
        }

        var articleContent        = document.createElement("DIV");
            articleContent.id     = "readability-content";
            articleContent.className = "readability-styled";

        /**
         * Now that we have the top candidate, look through its siblings for content that might also be related.
         * Things like preambles, content split by ads that we removed, etc.
        **/
        var siblingScoreThreshold = Math.max(12, topCandidate.readability.contentScore * 0.2);
        var siblingNodes          = topCandidate.parentNode == null ? [] : topCandidate.parentNode.childNodes;
        for(var i=0, il=siblingNodes.length; i < il; i++)
        {
            var siblingNode = siblingNodes[i];
            var append      = false;
            if (!siblingNode)
                continue;
            console.log("Looking at sibling node: " + siblingNode.tagName + " (" + siblingNode.className + ":" + siblingNode.id + ")" + ((typeof siblingNode.readability != 'undefined') ? (" with score " + siblingNode.readability.contentScore) : ''));
            console.log("Sibling has score " + (siblingNode.readability ? siblingNode.readability.contentScore : 'Unknown'));

            if(siblingNode === topCandidate)
            {
                append = true;
            }
            
            if(typeof siblingNode.readability != 'undefined' && siblingNode.readability.contentScore >= siblingScoreThreshold)
            {
                append = true;
            }
            
            if(siblingNode.nodeName == "P") {
                var linkDensity = readability.getLinkDensity(siblingNode);
                var nodeContent = readability.getInnerText(siblingNode, false);
                var nodeLength  = nodeContent.length;
                
                if(nodeLength > 80 && linkDensity < 0.25)
                {
                    append = true;
                }
                else if(nodeLength < 80 && linkDensity == 0 && nodeContent.search(/\.( |$)/) !== -1)
                {
                    append = true;
                }
            }
            if(siblingNode.nodeName == "IMG") {
                console.log("add sibling image for candidate node");
                append = true;
            }

            if(append)
            {
                console.log("Appending node: " + siblingNode)

                /* Append sibling and subtract from our list because it removes the node when you append to another node */
                articleContent.appendChild(siblingNode);
            }
        }                

        readability.grabArticleTitle(articleContent, articleContent.innerHTML.indexOf(topCandidate.innerHTML), topCandidate.innerHTML.length);

        readability.prepArticle(articleContent);

        var extractedText = readability.getInnerText(articleContent, false)
        var resultLength = extractedText.length;
        console.log("extracted content length " + resultLength);
        console.log("original content length " + totalLength);
        console.log("extracted content:" + articleContent.innerHTML);

       if (resultLength * 4 < totalLength || resultLength < 200)
           return null;

        var resultLinkDensity = readability.getLinkDensity(articleContent);
        var resultLinkNumDensity = readability.getLinkNumDensity(articleContent);
        console.log("result link density:" + resultLinkDensity + "link num density:" + resultLinkNumDensity);
        if (resultLinkDensity > 0.2 || (resultLinkDensity >= 0.02 && resultLinkNumDensity >= 0.1 ) 
            || (resultLinkDensity >= 0.01 && resultLinkNumDensity >= 0.6 )) {
            console.log("link is too densive:" + articleContent.id);
            return null;
        }

        return articleContent;
    },

    markArticleContent: function(e) {

        var next = e;
        while (next) {
            next.readabilityContent = true;
            next = next.parentNode;
        }
        readability.walkDOM(e, function(node) {
            if (node != null) {
                node.readabilityContent = true;
            }
        });
    },

    buildupMarkedNodes: function(src, dst) {
        if (!src || !dst)
            return;

        if (src && typeof src != 'undefined' && typeof src.readabilityContent != 'undefined') {
            var newElem = src.cloneNode(false);
            dst.appendChild(newElem);
            for (var i=0; i<src.childNodes.length; i++) {
                readability.buildupMarkedNodes(src.childNodes[i], newElem);
            }
        }
    },

    removeUnmarkedNodes: function(e) {
        readability.walkDOM(e, function(node){
            if (node && typeof node != 'undefined') {
                if (typeof node.readabilityContent != 'undefined') {
                    return true;
                } else {
                    if (node.parentNode != null) {
                        node.parentNode.removeChild(node);
                    }
                    return false;
                }
            }
        });
    },

    walkDOM: function(node, func) {
        if (!node)
            return;
        func(node);
        //if(node.childNodes) {
        //    for (var i=0; i<node.childNodes.length; i++) {
        //        var c=node.childNodes[i];
        //        readability.walkDOM(c, func);
        //    }
        //}
        node = node.firstChild;
        while (node) {
            var next = node.nextSibling;
            readability.walkDOM(node, func);
            node = next;
        }
    },

    logMarkState: function(e) {
        readability.walkDOM(e, function(node) {
            if (node != null && typeof node.readabilityContent != 'undefined') {
                console.log("log mark state: " + node.tagName + " : " + node.className);
            }
        });
    },
    /**
     * Get the inner text of a node - cross browser compatibly.
     * This also strips out any excess whitespace to be found.
     *
     * @param Element
     * @return string
    **/
    getInnerText: function (e, containsLink) {
        var textContent    = "";
        if (e == null)
        	return textContent;

        containsLink = (typeof containsLink == 'undefined') ? true : containsLink;

        //stackoverflow.com  find-all-text-nodes-in-html
        var n, walk=document.createTreeWalker(e, NodeFilter.SHOW_TEXT,null,false);
        while(n=walk.nextNode()) {
            if (n && n.parentNode) {
                if(typeof n.parentNode.style.display != 'undefined' && n.parentNode.style.display == "none") {
                    continue;
                }
                if(containsLink || n.parentNode.nodeName != "A") {
                    textContent+=n.textContent;
                }
            }
        }

        return textContent.replace( readability.regexps.normalizeRe, " ");
    },

    /**
     * Get the number of times a string s appears in the node e.
     *
     * @param Element
     * @param string - what to split on. Default is ","
     * @return number (integer)
    **/
    getCharCount: function (e,s) {
        s = s || ",";
        return readability.getInnerText(e).split(s).length;
    },

    /**
     * Remove the style attribute on every e and under.
     * TODO: Test if getElementsByTagName(*) is faster.
     *
     * @param Element
     * @return void
    **/
    cleanStyles: function (e) {
        e = e || document;
        var cur = e.firstChild;

        if(!e)
            return;

        // Remove any root styles, if we're able.
        if(typeof e.removeAttribute == 'function' && e.className != 'readability-styled') {
            e.removeAttribute('style');
            e.removeAttribute('class');
        }

        // Go until there are no more child nodes
        while ( cur != null ) {
            if ( cur.nodeType == 1 ) {
                // Remove style attribute(s) :
                if(cur.className != "readability-styled") {
                    cur.removeAttribute("style");
                    cur.removeAttribute('class');                    
                }
                readability.cleanStyles( cur );
            }
            cur = cur.nextSibling;
        }            
    },
    
    /**
     * Get the density of links as a percentage of the content
     * This is the amount of text that is inside a link divided by the total text in the node.
     * 
     * @param Element
     * @return number (float)
    **/
    getLinkDensity: function (e) {
        var links      = e.getElementsByTagName("a");
        var textLength = readability.getInnerText(e).length;
        var linkLength = 0;
        for(var i=0, il=links.length; i<il;i++)
        {
            linkLength += readability.getInnerText(links[i]).length;
        }        

        var density = linkLength / textLength;
        return density > 1.0 ? 1.0 : density;
    },
    //add by yangxuan
    getLinkNumDensity: function (e) {
        var linkNum      = e.getElementsByTagName("a").length;
        var paragraphNum = e.getElementsByTagName("p").length;

        var density = paragraphNum == 0  ? 1.0 : linkNum / paragraphNum;

        return density > 1.0 ? 1.0 : density;
    },

    //add by yangxuan
    hasInvalidParent: function (e) {
        var parentNode = e.parentNode;
        if (!parentNode) {
            return false;
        }

        if (parentNode.nodeName == "LI") {
            return true;
        } else {
            return readability.hasInvalidParent(parentNode);
        }
    },
    /**
     * Get an elements class/id weight. Uses regular expressions to tell if this 
     * element looks good or bad.
     *
     * @param Element
     * @return number (Integer)
    **/
    getClassWeight: function (e) {
        var weight = 0;

        /* Look for a special classname */
        if (e.className != "")
        {
            if(e.className.search(readability.regexps.negativeRe) !== -1)
                weight -= 25;

            if(e.className.search(readability.regexps.positiveRe) !== -1)
                weight += 25;                
        }

        /* Look for a special ID */
        if (typeof(e.id) == 'string' && e.id != "")
        {
            if(e.id.search(readability.regexps.negativeRe) !== -1)
                weight -= 25;

            if(e.id.search(readability.regexps.positiveRe) !== -1)
                weight += 25;                
        }

        return weight;
    },
    
    /**
     * Remove extraneous break tags from a node.
     *
     * @param Element
     * @return void
     **/
    killBreaks: function (e) {
        try {
            e.innerHTML = e.innerHTML.replace(readability.regexps.killBreaksRe,'<br />');        
        }
        catch (e) {
            console.log("KillBreaks failed - this is an IE bug. Ignoring.");
        }
    },

    /**
     * Clean a node of all elements of type "tag".
     * (Unless it's a youtube/vimeo video. People love movies.)
     *
     * @param Element
     * @param string tag to clean
     * @return void
     **/
    clean: function (e, tag) {
        var targetList = e.getElementsByTagName( tag );
        //var isEmbed    = (tag == 'object' || tag == 'embed');

        for (var y=targetList.length-1; y >= 0; y--) {
            console.log("clean node " + targetList[y].tagName);
            readability.removeUnmarkedNodes(targetList[y]);
        }
    },
    
    /**
     * Clean an element of all tags of type "tag" if they look fishy.
     * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
     *
     * @return void
     **/
    cleanConditionally: function (e, tag) {
        var tagsList      = e.getElementsByTagName(tag);
        var curTagsLength = tagsList.length;

        /**
         * Gather counts for other typical elements embedded within.
         * Traverse backwards so we can remove nodes at the same time without effecting the traversal.
         *
         * TODO: Consider taking into account original contentScore here.
        **/
        for (var i=curTagsLength-1; i >= 0; i--) {
            var weight = readability.getClassWeight(tagsList[i]);

            if(weight < 0)
            {
                console.log("Cleaning Conditionally 1:" + tagsList[i] + " (" + tagsList[i].tagName + ":" + tagsList[i].className + ")" + ((typeof tagsList[i].readability != 'undefined') ? (" with score " + tagsList[i].readability.contentScore) : ''));
                readability.removeUnmarkedNodes(tagsList[i]);
            }
            else if ( readability.getCharCount(tagsList[i],',') < 10) {
                /**
                 * If there are not very many commas, and the number of
                 * non-paragraph elements is more than paragraphs or other ominous signs, remove the element.
                **/

                var p      = tagsList[i].getElementsByTagName("p").length;
                var img    = tagsList[i].getElementsByTagName("img").length;
                var li     = tagsList[i].getElementsByTagName("li").length-100;
                var input  = tagsList[i].getElementsByTagName("input").length;
                var header1 = tagsList[i].getElementsByTagName("h1").length;
                var header2 = tagsList[i].getElementsByTagName("h2").length;

                var embedCount = 0;
                var embeds     = tagsList[i].getElementsByTagName("embed");
                for(var ei=0,il=embeds.length; ei < il; ei++) {
                    embedCount++;    
                }

                var linkDensity   = readability.getLinkDensity(tagsList[i]);
                var contentLength = readability.getInnerText(tagsList[i], false).length;
                var toRemove      = false;

                
                if(header1 == 1 || header2 == 1) {
                    toRemove = false;
                } else if(li > p && tag != "ul" && tag != "ol") {
                    toRemove = true;
                } else if( input > Math.floor(p/3) ) {
                     toRemove = true; 
                } else if(contentLength < 25 && (img == 0 || img > 6) ) {
                    toRemove = true;
                } else if(weight < 25 && linkDensity > .2) {
                    toRemove = true;
                } else if(weight >= 25 && linkDensity > .5) {
                    toRemove = true;
                } else if((embedCount == 1 && contentLength < 75) || embedCount > 1) {
                    toRemove = true;
                } 
                if(toRemove) {
                    console.log("Cleaning Conditionally 2:" + tagsList[i] + " (" + tagsList[i].tagName + ":" + tagsList[i].className + ")" + ((typeof tagsList[i].readability != 'undefined') ? (" with score " + tagsList[i].readability.contentScore) : ''));                
                    readability.removeUnmarkedNodes(tagsList[i]);
                }
            }
        }
    },

    /**
     * Clean out spurious headers from an Element. Checks things like classnames and link density.
     *
     * @param Element
     * @return void
    **/
    cleanHeaders: function (e) {
        for (var headerIndex = 1; headerIndex < 7; headerIndex++) {
            var headers = e.getElementsByTagName('h' + headerIndex);
            for (var i=headers.length-1; i >=0; i--) {
                if (readability.getClassWeight(headers[i]) < 0 || readability.getLinkDensity(headers[i]) > 0.33) {
                    headers[i].parentNode.removeChild(headers[i]);
                }
            }
        }
    },
    
    /**
     * Close the email popup. This is a hacktackular way to check if we're in a "close loop".
     * Since we don't have crossdomain access to the frame, we can only know when it has
     * loaded again. If it's loaded over 3 times, we know to close the frame.
     *
     * @return void
     **/
    removeFrame: function () {
        readability.iframeLoads++;
        if (readability.iframeLoads > 3)
        {
            var emailContainer = document.getElementById('email-container');
            if (null !== emailContainer) {
                emailContainer.parentNode.removeChild(emailContainer);
            }

            var kindleContainer = document.getElementById('kindle-container');
            if (null !== kindleContainer) {
                kindleContainer.parentNode.removeChild(kindleContainer);
            }

            readability.iframeLoads = 0;
        }            
    },
    
    htmlspecialchars: function (s) {
        if (typeof(s) == "string") {
            s = s.replace(/&/g, "&amp;");
            s = s.replace(/"/g, "&quot;");
            s = s.replace(/'/g, "&#039;");
            s = s.replace(/</g, "&lt;");
            s = s.replace(/>/g, "&gt;");
        }
    
        return s;
    },

    updateReaderModeAccessible: function() {
        var accessibleResult = 0;
        if (readability.extractedContent.length > 100) {
            accessibleResult = 2;
        }
        window.readermode.readerModeAccessible(readability.webviewId, accessibleResult);
    },

    openReaderPannel: function() {
        console.log("open reader mode");
        window.readermode.openReaderPannel(readability.extractedContent);
    },

    sendFeedback: function(type) {
        console.log("sendFeedback reader mode" + type);
        window.readermode.sendFeedback(type);
    },


    createFeedbackPanel: function() {
            // feedback panel
            var panel = document.createElement("DIV");
            panel.id = "feedbackPanel";
            panel.style.display = "block";
            panel.style.overflow = "scroll";
            panel.style.opacity = "1.0";
            panel.style.background = "#fff";
            panel.style.width = "100%";
            panel.style.left = 0;
            panel.innerHTML = "<hr color='#cccccc' width='90%' height='0.2px'/><span class='reader_notice'>Help us improve Reader mode! Can you tell us if the layout of the page is correct?</span>"
            + "<div class='reader_img_panel'><img onclick='reader.changeImage(true); window.readermode.sendFeedback(0);' class='reader_img_btn_left' id='btn-like' src='**READERBILITY**/like_normal.png'/><img onclick='reader.changeImage(false); window.readermode.sendFeedback(1);' class='reader_img_btn_right' id='btn-dislike' src='**READERBILITY**/dislike_normal.png'/></div>"
            + "<div class='reader_link'><a onclick='window.readermode.sendFeedback(2); return false;' href='#'>Tap here to give us your suggestion</a></div><br><br>";
            return panel;

        },

};