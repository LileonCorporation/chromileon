var reader = {

    changeImage : function(feedback) {

            var likebtn = document.getElementById("btn-like");
            var dislikebtn = document.getElementById("btn-dislike");
            if (feedback) {
                likebtn.src = "**READERBILITY**/like_pressed.png";
                dislikebtn.src = "**READERBILITY**/dislike_normal.png";
            } else {
                likebtn.src = "**READERBILITY**/like_normal.png";
                dislikebtn.src = "**READERBILITY**/dislike_pressed.png";
            }

        },


}